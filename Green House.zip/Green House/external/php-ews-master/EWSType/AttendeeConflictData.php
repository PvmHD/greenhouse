<?php
/**
 * Contains EWSType_AttendeeConflictData.
 */

/**
 * Represents an attendee that has conflicting data.
 *
 * @package php-ews\Types
 */
class EWSType_AttendeeConflictData extends EWSType
{

}
