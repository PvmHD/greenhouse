<?php
/**
 * Contains EWSType_BaseRequestType.
 */

/**
 * Base class for requests.
 *
 * @package php-ews\Types
 */
class EWSType_BaseRequestType extends EWSType
{

}
