<?php
/**
 * Contains EWS_Exception.
 */

/**
 * Exception class for Exchange Web Services.
 *
 * @package php-ews\Exception
 */
class EWS_Exception extends Exception
{
}
