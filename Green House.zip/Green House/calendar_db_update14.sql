ALTER TABLE `users` ADD `title` VARCHAR( 55 ) NOT NULL AFTER `user_id` ;

