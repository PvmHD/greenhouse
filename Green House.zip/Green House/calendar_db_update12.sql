
ALTER TABLE `current_editing` ADD INDEX ( `edit_date` ) ;