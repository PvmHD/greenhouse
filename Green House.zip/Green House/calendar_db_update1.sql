ALTER TABLE `calendars` ADD `initial_show` TINYINT( 1 ) NOT NULL DEFAULT '0' AFTER `can_dd_drag` ;

