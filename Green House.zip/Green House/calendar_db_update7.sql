ALTER TABLE `repeating_events` ADD `yearmonthday` INT( 2 ) NULL AFTER `monthday` ,
ADD `yearmonth` INT( 2 ) NULL AFTER `yearmonthday` ;
