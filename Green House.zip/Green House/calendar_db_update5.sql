
ALTER TABLE `calendars` ADD `calendar_admin_email` VARCHAR( 255 ) NULL ;


