ALTER TABLE `events` ADD `team_member_id` INT(11) NULL AFTER `user_id`;

